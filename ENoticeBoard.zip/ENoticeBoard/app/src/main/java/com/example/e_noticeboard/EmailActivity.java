package com.example.e_noticeboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class EmailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
    }

    public void loginActivity(View view) {
        Intent intent = new Intent(this, LoginPassword.class);
        startActivity(intent);

    }

    public void registerActivity(View view) {
        Intent intent = new Intent(this, RegisterPassword.class);
        startActivity(intent);

    }
}
